﻿using System;

namespace BoxOfT
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Box<int> box = new Box<int>();
            box.Add(5);
            box.Add(6);
            box.Add(7);
            box.Remove();
            Console.WriteLine(box.Count);
        }
    }
}
