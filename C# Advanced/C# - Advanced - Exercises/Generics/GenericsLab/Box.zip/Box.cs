﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {
        private List<T> box;
        public int Count { get; private set; }

        public Box()
        {
            box = new List<T>();
        }

        public void Add(T element)
        {
            box.Add(element);
            Count++;
        }
        public T Remove()
        {
            T lastElement = box.Last();
            box.Remove(lastElement);
            Count--;
            return lastElement;
        }
    }
}
