﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-Q9P5HVT\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}