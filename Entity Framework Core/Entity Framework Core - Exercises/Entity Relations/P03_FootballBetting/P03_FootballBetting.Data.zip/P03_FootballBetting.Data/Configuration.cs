﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal static class Configuration
    {
        public static string ConectionString => @"Server=DESKTOP-Q9P5HVT\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
