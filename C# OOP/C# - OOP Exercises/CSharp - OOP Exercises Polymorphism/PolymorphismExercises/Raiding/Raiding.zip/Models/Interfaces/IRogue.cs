﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Models.Interfaces
{
    public interface IRogue : IBaseHero
    {
    }
}
