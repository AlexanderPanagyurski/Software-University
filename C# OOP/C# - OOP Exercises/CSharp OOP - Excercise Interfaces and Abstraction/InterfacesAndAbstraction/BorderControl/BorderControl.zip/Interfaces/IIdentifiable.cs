﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIdentifiable
    {
        string Id { get; }
        bool isFakeId(string fakeNumbers);
    }
}
